# Hearth — your pantry app

This is a working pantry tracker. Add items, track expirations, scan receipts (demo mode), get recipe ideas, manage a shopping list. Data saves to your phone's browser.

## What's in this folder

- `index.html` — the app itself
- `app.js` — all the app logic
- `manifest.json` — tells iPhone to treat this as an app
- `icon.png` — the home-screen icon

## How to get it on your iPhone (start to finish, 20 min)

### Step 1: Make a free GitHub account
1. Go to https://github.com and click "Sign up"
2. Use your email, pick a username (this becomes part of your code's web address)
3. Verify your email

### Step 2: Upload your code to GitHub
1. Once logged in, click the green "New" button (or the + in the top right → "New repository")
2. Repository name: `hearth-pantry`
3. Set it to "Public"
4. Check the box "Add a README file"
5. Click "Create repository"
6. On the new page, click "Add file" → "Upload files"
7. Drag all 4 files from the zip I gave you (index.html, app.js, manifest.json, icon.png) into the upload area
8. Scroll down, click "Commit changes"

### Step 3: Deploy with Vercel
1. Go to https://vercel.com and click "Sign Up"
2. Choose "Continue with GitHub" (easiest — connects them automatically)
3. Approve the permissions
4. On the Vercel dashboard, click "Add New..." → "Project"
5. Find your `hearth-pantry` repo and click "Import"
6. Leave all settings as-is and click "Deploy"
7. Wait ~30 seconds. You'll get a URL like `hearth-pantry-yourname.vercel.app`

### Step 4: Install on your iPhone
1. Open Safari on your iPhone (must be Safari, not Chrome)
2. Go to your Vercel URL
3. Tap the Share button (square with arrow up) at the bottom
4. Scroll down, tap "Add to Home Screen"
5. Edit the name if you want, tap "Add"
6. The Hearth icon now lives on your home screen

When you tap the icon, it opens fullscreen, no Safari bars — just like an app.

## Updating the app later

When we want to change something:
1. Edit the file on GitHub (or upload a new version)
2. Vercel automatically rebuilds and deploys within ~30 seconds
3. Reopen the app on your phone — new version is live

That's the magic of this setup. No app store re-submissions.
